function onSignIn(googleUser) {
    const profile = googleUser.getBasicProfile();
    const email = profile.getEmail();

    // Send the Google user data to the server
    fetch('auth.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Display the OTP on the UI
            document.getElementById('otp').innerText = data.otp;
            document.getElementById('otp-container').style.display = 'block';
            // Set a timer to hide the OTP after 30 seconds
            setTimeout(() => {
                document.getElementById('otp-container').style.display = 'none';
            }, 30000);
        } else {
            // Handle unsuccessful OTP generation
            console.error('Error:', data.error);
            // Display a meaningful error message to the user
        }
    })
    .catch(error => {
        console.error('Error:', error);
        // Handle other errors and display a meaningful message to the user
    });
}
