<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    // Validate and sanitize email 
    $email = $data['email'];

    // Simulate successful OTP generation (replace with actual logic)
    $otp = generateOTP();

    // Respond with success and OTP
    echo json_encode(['success' => true, 'otp' => $otp]);
} else {
    // Handle unauthorized access or redirect to the homepage
    header('Location: index.html');
    exit;
}

function generateOTP()
{
    // Implement OTP generation logic 
    return bin2hex(random_bytes(4)); // 8 characters
}
